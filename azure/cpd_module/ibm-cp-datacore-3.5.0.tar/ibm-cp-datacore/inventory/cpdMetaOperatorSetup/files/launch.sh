#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# Script install Couchdb Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI)
# application of kubernetes manifests in both an online and offline airgap environment.  This script can be invoked using
# `cloudctl`, a command line tool to manage Container Application Software for Enterprises (CASEs), or directly on an
# uncompressed CASE archive.  Running the script through `cloudctl case launch` has added benefit of pre-requisite validation
# and verification of integrity of the CASE.  Cloudctl download and usage istructions are available at [github.com/IBM/cloud-pak-cli](https://github.com/IBM/cloud-pak-cli).
#
# Pre-requisites:
#   oc or kubectl installed
#   sed installed
#   CASE tgz downloaded & uncompressed
#   authenticated to cluster
#
# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action="install-operator-native"
caseJsonFile=""
casePath="${scriptDir}/../../.."
caseName="ibm-cp-datacore"
inventory="cpdMetaOperatorSetup"
instance=""

# - optional parameter / argument defaults
dryRun=""
deleteCRDs=0
namespace=""
registry=""
pass=""
secret=""
user=""
inputcasedir=""
cr_system_status="betterThanYesterday"
recursive_catalog_install=0

# - variables specific to catalog/operator installation
caseCatalogName="ibm-cp-data-operator-catalog"
catalogNamespace="openshift-marketplace"
channelName="v1.0"
catalogDigest=":latest"
couchDeployment="deployment.apps/ibm-cp-data-operator" #dependency

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cp-data-operator}"
OPERATOR_TAG="${OPERATOR_TAG:-v1.0.0-x86_64}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-docker.io/ibmcom}"
entitledSecret="ibm-entitlement-key"
entitledRegistry="cp.icr.io/cp/cpd"

# Display usage information with return code (if specified)
print_usage() {
    # Determine context of call (via cloudctl or script directly) based on presence of cananical json parameter
    if [ -z "$caseJsonFile" ]; then
        usage="${scriptName} --casePath <CASE-PATH>"
        caseParmDesc="--casePath value, -c value  : root director to extracted CASE file to parse"
        toleranceParm=""
        toleranceParmDesc=""
    else
        usage="cloudctl case launch --case <CASE-PATH>"
        caseParmDesc="--case value, -c value      : local path or URL containing the CASE file to parse"
        toleranceParm="--tolerance tolerance"
        toleranceParmDesc="
  --tolerance value, -t value : tolerance level for validating the CASE
                                 0 - maximum validation (default)
                                 1 - reduced valiation"
    fi
    echo "
USAGE: ${usage} --inventory inventoryItemOfLauncher --action launchAction --instance instance
                  --args \"args\" --namespace namespace ${toleranceParm}
OPTIONS:
   --action value, -a value    : the name of the action item launched
   --args value, -r value      : arguments specific to action (see 'Action Parameters' below).
   ${caseParmDesc}
   --instance value,  -i value : name of instance of target application (release)
   --inventory value, -e value : name of the inventory item launched
   --namespace value, -n value : name of the target namespace
   ${toleranceParmDesc}
 ARGS per Action:
    configure-creds-airgap
      --registry               : source/target container image registry (required)
      --user                   : login user name for the container image registry (required)
      --pass                   : login password for the container image registry (required)
    configure-cluster-airgap
      --dryRun                 : simulate configuration of custer for airgap
      --inputDir               : path to saved CASE directory
      --registry               : target container image registry (required)
    mirror-images
      --dryRun                 : simulate configuration of custer for airgap
      --inputDir               : path to saved CASE directory
      --registry               : target container image registry (required)
    install-catalog:
      --registry               : target container image registry (required)
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)
    install-operator:
      --channelName            : name of channel for subscription (packagemanifest default used if not specified)
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if registry|pass specified)
      --pass                   : login password for the container image registry (required if registry|user specified)
    install-operator-native:
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if registry|pass specified)
      --pass                   : login password for the container image registry (required if registry|user specified)
    configure-cluster-airgap-native:
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if registry|pass specified)
      --pass                   : login password for the container image registry (required if registry|user specified)
    uninstall-catalog          : uninstalls the catalog source and operator group
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)
    uninstall-operator         : delete the operator deployment via OLM
    uninstall-operator-native  : deletes the operator deployment via native way
      --deleteCRDs             : deletes CRD's associated with this operator (if not set, crds won't get deleted)
    apply-custom-resources     : creates the sample custom resource
      --systemStatus           : status to display
    delete-custom-resources    : deletes the same custom resource
"

    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

# ***** ARGUMENT CHECKS *****

# Validates that the required parameters were specified for script invocation
check_cli_args() {
    # Verify required parameters were specifed and are valid (including environment setup)
    # - case path
    [[ -z "${casePath}" ]] && { err_exit "The case path parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml in the root of the specified case path parameter."; }

    # Verify kubernetes connection and namespace
    check_kube_connection
    [[ -z "${namespace}" ]] && { err_exit "The namespace parameter was not specified."; }
    if ! $kubernetesCLI get namespace "${namespace}" >/dev/null; then
        err_exit "Unable to retrieve namespace specified ${namespace}"
    fi

    # Verify dynamic args are valid (show as any issues on invocation as possible)
    parse_dynamic_args
}

# Parses the args (--args) parameter if any are specified
parse_dynamic_args() {
    _IFS=$IFS
    IFS=" "
    read -ra arr <<<"${1}"
    IFS="$_IFS"
    arr+=("")
    idx=0
    v="${arr[${idx}]}"

    while [ "$v" != "" ]; do
        case $v in
        # Enable debug from cloudctl invocation
        --debug)
            idx=$((idx + 1))
            set -x
            ;;
        --dryRun)
            dryRun="--dry-run"
            ;;
        --deleteCRDs)
            deleteCRDs=1
            ;;
        --channelName)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            channelName="${v}"
            ;;
        --catalogDigest)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            catalogDigest="@${v}"
            ;;
        --registry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry="${v}"
            ;;
        --entitledRegistry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledRegistry="${v}"
            ;;
        --inputDir)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            inputcasedir="${v}"
            ;;
        --user)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            user="${v}"
            ;;
        --entitledUser)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledUser="${v}"
            ;;
        --pass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            pass="${v}"
            ;;
        --entitledPass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledPass="${v}"
            ;;
        --secret)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            secret="${v}"
            ;;
        --systemStatus)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            cr_system_status="${v}"
            ;;
        --recursive)
            recursive_catalog_install=1
            ;;
        --help)
            print_usage 0
            ;;
        *)
            err_exit "Invalid Option ${v}" >&2
            ;;
        esac
        idx=$((idx + 1))
        v="${arr[${idx}]}"
    done
}

# Check if all secret parameters are included
check_secret_params() {

    local foundError=0

    [[ -z ${secret} ]] && {
        foundError=1
        err "'--secret' is required for creating a registry secret"
    }
    [[ -z ${registry} ]] && {
        foundError=1
        err "'--registry' is required for creating a registry secret"
    }
    [[ -z ${user} ]] && {
        foundError=1
        err "'--user' is required for creating a registry secret"
    }
    [[ -z ${pass} ]] && {
        foundError=1
        err "'--pass' is required for creating a registry secret"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

check_entitled_secret_params() {

    local foundError=0

    [[ -z ${entitledRegistry} ]] && {
        foundError=1
        err "'--entitledRegistry' is required for creating a entitled registry secret"
    }
    [[ -z ${entitledUser} ]] && {
        foundError=1
        err "'--entitledUser' is required for creating a entitled registry secret"
    }
    [[ -z ${entitledPass} ]] && {
        foundError=1
        err "'--entitledPass' is required for creating a entitled registry secret"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

# Validates that the required args were specified for install action
validate_install_args() {
    # Verify arguments required per install method were provided
    echo "Checking install arguments"

    # Validate secret arguments provided are valid combination and
    #   either create or check for existence of secret in cluster.
    if [[ -n "${registry}" || -n "${user}" || -n "${pass}" ]]; then
        check_secret_params
        set -e
        $kubernetesCLI create secret docker-registry "${secret}" \
            --docker-server="${registry}" \
            --docker-username="${user}" \
            --docker-password="${pass}" \
            --docker-email="${user}" \
            --namespace "${namespace}"
        set +e
    elif [[ -n ${secret} ]]; then
        if ! $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
            err "Secret $secret does not exist, either create one or supply additional registry parameters to create one"
            print_usage 1
        fi
    fi

    if [[ -n "${entitledUser}" || -n "${entitledPass}" ]]; then
        check_entitled_secret_params
        if $kubernetesCLI get secrets "${entitledSecret}" -n "${namespace}" >/dev/null 2>&1; then
            echo "Secret ${entitledSecret} already exists, skipping create"
        else
            set -e
            $kubernetesCLI create secret docker-registry "${entitledSecret}" \
                --docker-server="$( echo ${entitledRegistry} | cut -d'/' -f 1)" \
                --docker-username="${entitledUser}" \
                --docker-password="${entitledPass}" \
                --docker-email="${entitledUser}" \
                --namespace "${namespace}"
            set +e
        fi
    fi
}

validate_install_catalog() {

    # using a mode flag to share the validation code between install and uninstall
    local mode="$1"

    echo "Checking arguments for install-catalog action"

    if [[ ${mode} != "uninstall" && -z "${registry}" ]]; then
        err "'--registry' must be specified with the '--args' parameter"
        print_usage 1
    fi

    if [[ ${recursive_catalog_install} -eq 1 && -z "${inputcasedir}" ]]; then
        err "'--inputDir' must be specified with the '--args' parameter when '--recursive' is set"
        print_usage 1
    fi
}

# Validates that the required args were specified for secret creation
validate_configure_creds_airgap_args() {
    # Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }
    [[ -z "${user}" ]] && {
        foundError=1
        err "'--user' must be specified with the '--args' parameter"
    }
    [[ -z "${pass}" ]] && {
        foundError=1
        err "'--pass' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_configure_cluster_airgap_args() {
# Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }

    [[ -z "${inputcasedir}" ]] && {
        foundError=1
        err "'--inputDir' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_configure_cluster_airgap_native_args() {
# Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_file_exists() {
    local file=$1
    [[ ! -f ${file} ]] && { err_exit "${file} is missing, exiting deployment."; }
}

# ***** END ARGUMENT CHECKS *****

# ***** UTILS *****

assert() {
    testname="$1"
    got=$2
    want=$3
    if [ "$got" != "$want" ]; then
        err_exit "got $got, but want $want : ${testname} failed"
    fi
}
# ***** END UTILS *****

# ***** ACTIONS *****

# ----- CONFIGURE ACTIONS -----

# Add / update local authentication store with user/password specified (~/.airgap/secrets/<registy>.json)
# Add / update local authentication store with user/password specified (~/.airgap/secrets/<registy>.json)
configure_creds_airgap() {
    echo "-------------Configuring authentication secret-------------"

    validate_configure_creds_airgap_args

    # Create registry secret for user information provided

    "${scriptDir}"/airgap.sh registry secret -c -u "${user}" -p "${pass}" "${registry}"
}

# Append secret to Global Cluster Pull Secret (pull-secret in openshif-config)
configure_cluster_pull_secret() {

    echo "-------------Configuring cluster pullsecret-------------"

    # configure global pull secret if an authentication secret exists on disk
    if "${scriptDir}"/airgap.sh registry secret -l | grep "${registry}"; then
        "${scriptDir}"/airgap.sh cluster update-pull-secret --registry "${registry}" "${dryRun}"
    else
        echo "Skipping configuring cluster pullsecret: No authentication exists for ${registry}"
    fi
}

configure_content_image_source_policy() {

    echo "-------------Configuring imagecontentsourcepolicy-------------"

    "${scriptDir}"/airgap.sh cluster apply-image-policy \
        --name "${caseName}" \
        --dir "${inputcasedir}" \
        --registry "${registry}" "${dryRun}"
}

# Apply ImageContentSourcePolicy required for airgap
configure_cluster_airgap_native() {

    echo "-------------Configuring cluster for airgap native-------------"

    validate_configure_cluster_airgap_native_args

    if $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
       echo "Secret ${secret} already exists, skipping create"
    else
       set -e
       $kubernetesCLI create secret generic "${secret}" \
       --from-literal=url="${registry}" \
       --from-literal=user="${user}" \
       --from-literal=key="${pass}" \
       --namespace "${namespace}"
       set +e
    fi

    OPERATOR_IMAGE_FULL_PATH=${registry}/${OPERATOR_IMAGE}:${OPERATOR_TAG}

    sed -i -- "s#docker.io/ibmcom#${OPERATOR_IMAGE_FULL_PATH}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
}

# Apply ImageContentSourcePolicy required for airgap
configure_cluster_airgap() {

    echo "-------------Configuring cluster for airgap-------------"

    validate_configure_cluster_airgap_args

    configure_cluster_pull_secret

    configure_content_image_source_policy

    if $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
       echo "Secret ${secret} already exists, skipping create"
    else
       set -e
       $kubernetesCLI create secret generic "${secret}" \
       --from-literal=url="${registry}" \
       --from-literal=user="${user}" \
       --from-literal=key="${pass}" \
       --namespace "${namespace}"
       set +e
    fi
}

# ----- MIRROR ACTIONS -----

# Mirror required images
mirror_images() {
    echo "-------------Mirroring images-------------"

    validate_configure_cluster_airgap_args

    "${scriptDir}"/airgap.sh image mirror \
        --dir "${inputcasedir}" \
        --to-registry "${registry}" "${dryRun}"
}

# ----- INSTALL ACTIONS -----

install_dependent_catalogs() {
    echo "Not Implemented"
}

install_operator_group() {
    echo "-------------Installing operator group-------------"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/operator-group.yaml
}

# Installs the catalog source and operator group
install_catalog() {
   echo "-------------Installing catalog source-------------"
   validate_install_catalog

   local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml

   # Verfy expected yaml files for install exit
   validate_file_exists "${catsrc_file}"

   # Apply yaml files manipulate variable input as required

   local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
   echo "orig - ${catsrc_image_orig}"  
   # replace original registry with local registry
   local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
   echo "mod - ${catsrc_image_mod}"
   # apply catalog source
   sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | $kubernetesCLI apply -f -
}

# Install utilizing default OLM method
install_operator() {

    validate_install_args
    echo "-------------Installing via OLM-------------"
    install_operator_group

    # link secret in openshift-marketplace
    if [[ "$secret" != "" ]]; then
       $kubernetesCLI get secret ${secret} -n ${namespace} --export -o yaml | $kubernetesCLI apply -n ${catalogNamespace} -f -
       $kubernetesCLI secrets link serviceaccount/default ${secret} --for=pull -n ${catalogNamespace}
       $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source-staging.yaml
    else
       $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml
    fi

	echo "Wait for catalog installation to complete"
	sleep 30

	$kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/subscription.yaml
    echo "Wait for subscription to complete"
	sleep 60
	
    if [[ "$secret" != "" ]]; then
       $kubernetesCLI secrets link serviceaccount/ibm-cp-data-operator-serviceaccount ${secret} --for=pull -n ${namespace} 
       # restart pod to refresh secret
	   $kubernetesCLI delete pod -l name=ibm-cp-data-operator
    fi
   

}

# Install utilizing default CLI method
install_operator_native() {

    validate_install_args
   
    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}:${OPERATOR_TAG}

    echo "Install Operator Native..."
    sed -i -- "s#docker.io/ibmcom#${OPERATOR_REGISTRY}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    sed -i -- "s#\"ENTITLED_REGISTRY\"#\"${entitledRegistry}\"#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    sed -i -- "s#REPLACE_NAMESPACE#${namespace}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml

    echo "pre install"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/metaoperator.cpd.ibm.com_cpdservices_crd.yaml
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role.yaml
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml 
    if [[ "$secret" != "" ]]; then
       $kubernetesCLI secrets link ibm-cp-data-operator-serviceaccount ${secret} --for=pull -n ${namespace} 
    fi
   
    echo "installing operator"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
}

# install operand custom resources
apply_custom_resources() {

    echo "Not Implemented"
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "Not Implemented"
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "-------------Uninstalling catalog-------------"
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/subscription.yaml
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/operator-group.yaml	
	$kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling OLM-------------"
	
	uninstall_catalog

    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/olm-catalog/ibm-cp-data-operator/1.0.0/ibm-cp-data-operator.v1.0.0.clusterserviceversion.yaml

    delete_resources
}

# Uninstall operator installed via CLI
uninstall_operator_native() {

    echo "-------------Uninstall operator native-------------"
   
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml 
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role.yaml
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml

    delete_custom_resources

    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml

    delete_resources

}

delete_resources() {

    echo "-------------Deleting operator resources-------------"
    if [[ "$secret" != "" ]]; then
        $kubernetesCLI delete secret "${secret}" -n ${namespace} --ignore-not-found=true
    fi
    $kubernetesCLI delete secret ibm-entitlement-key -n ${namespace} --ignore-not-found=true
    $kubernetesCLI delete all -l app.kubernetes.io/managed-by=ibm-cp-data-operator -n ${namespace}
    $kubernetesCLI delete cm cpd-meta-admin-config cpd-meta-operator-lock -n ${namespace} --ignore-not-found=true
}

delete_custom_resources() {
     echo "-------------Uninstall custom resources-------------"
     $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/metaoperator.cpd.ibm.com_cpdservices_crd.yaml
}

# ***** END ACTIONS *****

# Verifies that we have a connection to the Kubernetes cluster
check_kube_connection() {
    # Check if default oc CLI is available and if not fall back to kubectl
    command -v $kubernetesCLI >/dev/null 2>&1 || { kubernetesCLI="kubectl"; }
    command -v $kubernetesCLI >/dev/null 2>&1 || { err_exut "No kubernetes cli found - tried oc and kubectl"; }

    # Query apiservices to verify connectivity
    if ! $kubernetesCLI get apiservices >/dev/null 2>&1; then
        # Developer note: A kubernetes CLI should be included in your prereqs.yaml as a client prereq if it is required for your script.
        err_exit "Verify that $kubernetesCLI is installed and you are connected to a Kubernetes cluster."
    fi
}

# Run the action specified
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    configureCredsAirgap)
        configure_creds_airgap
        ;;
    configureClusterAirgap)
        configure_cluster_airgap
        ;;
    configureClusterAirgapNative)
        configure_cluster_airgap_native
        ;;
    installCatalog)
        install_catalog
        ;;
    installOperator)
        install_operator
        ;;
    installOperatorNative)
        install_operator_native
        ;;
    mirrorImages)
        mirror_images
        ;;
    uninstallCatalog)
        uninstall_catalog
        ;;
    uninstallOperator)
        uninstall_operator
        ;;
    uninstallOperatorNative)
        uninstall_operator_native
        ;;
    applyCustomResources)
        apply_custom_resources
        ;;
    deleteCustomResources)
        delete_custom_resources
        ;;
    *)
        err "Invalid Action ${action}" >&2
        print_usage 1
        ;;
    esac
}

# Error reporting functions
err() {
    echo >&2 "[ERROR] $1"
}
err_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

# Parse CLI parameters
while [ "${1-}" != "" ]; do
    case $1 in
    # Supported parameters for cloudctl & direct script invocation
    --casePath | -c)
        shift
        casePath="${1}"
        ;;
    --caseJsonFile)
        shift
        caseJsonFile="${1}"
        ;;
    --inventory | -e)
        shift
        inventory="${1}"
        ;;
    --action | -a)
        shift
        action="${1}"
        ;;
    --namespace | -n)
        shift
        namespace="${1}"
        ;;
    --instance | -i)
        shift
        instance="${1}"
        ;;
    --args | -r)
        shift
        parse_dynamic_args "${1}"
        ;;

    # Additional supported parameters for direct script invocation ONLY
    --help)
        print_usage 0
        ;;
    --debug)
        set -x
        ;;

    *)
        echo "Invalid Option ${1}" >&2
        exit 1
        ;;
    esac
    shift
done

# Execution order
check_cli_args
run_action