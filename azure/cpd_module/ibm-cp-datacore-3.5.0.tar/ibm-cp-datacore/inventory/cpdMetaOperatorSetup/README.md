# Cloud Pak for Data Operator

 Cloud Pak for Data can be installed in an online or a airgapped environment using the operator. 

 - [Prerequisites](#prerequisites)
 - [Online Installation](#online-installation)
   - [Non-OLM](#non-olm)
     - [Operator Installation](#operator-installation)
   - [OLM (OCP 4.x)](#olm)
     - [Using OpenShift Console](#using-openshift-console)
       - [Install Catalog](#install-cpd-catalog)
       - [Operator Installation](#install-cpd-operator-using-console)
     - [Using CLI](#using-cli)
       - [Catalog & Operator Installation](#install-cpd-operator-thru-cli)
- [Airgapped Installation](#airgapped-installation)
  - [Set up](#set-up-for-airgapped-environment)
     - [Operator Installation Airgapped](#operator-installation-airgapped)
 - [Using Cloud Pak for Data Pre-load Images](#using-cloud-pak-for-data-pre-load-mages)
 - [Cloud Pak for Data Control Plane Installation](#cloud-pak-for-data-control-plane-installation) 

 
## Prerequisites

 - cluster admininstator access to the OpenShift cluster
 - [`cloudctl` tool](https://github.com/IBM/cloud-pak-cli/releases) to run case commands
 - [`cpd-cli` tool](https://github.com/IBM/cpd-cli/releases) to prepare your private CPD registry for Airgapped environment.
 - Red Hat OpenShift version 3.11 or 4.3+
 - [Cloud Pak for Data case](https://github.com/IBM/cloud-pak/blob/master/repo/case/ibm-cp-datacore/3.5.0/ibm-cp-datacore-3.5.0.tgz) package tar file
 - A private docker registry for airgapped environments
 - In-cluster or a shared registry with sufficient size and proximity to CPD cluster 
 - A bastion node with internet connectivity and the access to the OpenShift cluster
 - Dynamic volume Provisioner or a storage class on the cluster that is supported by CPD
 - OpenShift projects
   - A "Meta Ops" project with a user with cluster administrator role 
   - A CPD Instance project with a user with a project admin or editor role.
   
 ## Online Installation

 - Download and extract the 

    `tar -xf ibm-cp-datacore-3.5.0.tgz`

   The case directory should have the extracted case archive.

 ### Set up
 
   - Create the Meta ops project
  
    `oc new-project cpd-meta-ops`
    
   - Set up environment variables

    ```bash
     export OPERATOR_REGISTRY=docker.io/ibmcom    
     export CPD_REGISTRY=cp.icr.io/cp/cpd
     export CPD_REGISTRY_USER=cp
     export CPD_REGISTRY_PASSWORD=<apikey>
        
     export NAMESPACE=$(oc project -q)
    ```
   
### Non-OLM

### Operator Installation

 - (For OCP 3.11 ONLY) Create Service Account and assign cluster admin role
 
      ```
      cat <<EOF | oc apply -f -
      apiVersion: v1
      kind: ServiceAccount
      metadata:
        name: ibm-cp-data-operator-serviceaccount
      EOF

      oc adm policy add-cluster-role-to-user cluster-admin system:serviceaccount:${NAMESPACE}:ibm-cp-data-operator-serviceaccount
      ```
 
 - Install the operator 

      ```bash
      cloudctl case launch                        \
        --case ibm-cp-datacore                    \
        --namespace=${NAMESPACE}                  \
        --inventory cpdMetaOperatorSetup          \
        --action install-operator-native          \
        --tolerance=1                             \
        --args "--registry ${OPERATOR_REGISTRY} --user ${OPERATOR_REGISTRY_USER} --pass ${OPERATOR_REGISTRY_PASSWORD} --entitledRegistry ${CPD_REGISTRY} --entitledUser ${CPD_REGISTRY_USER} --entitledPass ${CPD_REGISTRY_PASSWORD}"
      ```

     Check the operator `ibm-cp-data-operator` deployed successfully
         

### OLM

### Using OpenShift Console

#### Prerequisites

 - Create a CPD meta namespace, say `cpd-meta-ops` and an instance namespace `cpd-tenant`
 
 - Create entitlement secret and add to operator service account of `cpd-meta-ops` project

    `oc create secret docker-registry ibm-entitlement-key --docker-server=cp.icr.io/cp/cpd --docker-username=cp --docker-password=< api key > -n cpd-meta-ops`

#### Install CPD Catalog

  Log into the OpenShift console using cluster administrator credentials.

  Navigate to Menu-->Administration-->Cluster Settings-->Global Configuration-->Operator Hub-->Sources

  Click on "Create Catalog Source" and fill in the details

    name: ibm-cp-data-operator-catalog
    displayName: Cloud Pak for Data 
    image: docker.io/ibmcom/ibm-cp-data-operator-catalog:latest 
    publisher: IBM

  Select the default availability as "Cluster-wide catalog source"

  Hit "Create"

  After a few minutes the CPD Operator will be listed in the Menu-->Operators-->Operator Hub Catalog in the "Custom" Providers section.

#### Install CPD Operator using console

  Click on the `IBM Cloud Pak for Data Operator` --> Install

  On the Install page, select the default options to create the Subscription

    Installation Mode - All namespaces on the cluster
    Update Channel - v1.0
    Approval Strategy - Automatic

  Click on "Subscribe"

  At this point the operator pod will started.

### Using CLI

#### Install CPD Operator thru CLI

  -  Install the catalog and operator

      ```bash
      cloudctl case launch                          \
          --case ibm-cp-datacore                    \
          --namespace ${NAMESPACE}                  \
          --inventory cpdMetaOperatorSetup          \
          --action install-operator                 \
          --tolerance=1                             \
         --args "--registry ${OPERATOR_REGISTRY} --user ${OPERATOR_REGISTRY_USER} --pass ${OPERATOR_REGISTRY_PASSWORD} --entitledRegistry ${CPD_REGISTRY} --entitledUser ${CPD_REGISTRY_USER} --entitledPass ${CPD_REGISTRY_PASSWORD}"
      ```

     Check the operator `ibm-cp-data-operator` deployed successfully


## Airgapped Installation

### Set up for Airgapped Environment

   - Prepare a [private registry](https://www.ibm.com/support/knowledgecenter/SSGT7J_20.2/install/mirroring_operators.html#registry) and a [bastion node](https://www.ibm.com/support/knowledgecenter/SSGT7J_20.2/install/mirroring_operators.html#bastion) 
   - Download the case archive from github and save 

      `export CASE_ARCHIVE=ibm-cp-datacore-3.5.0.tgz`
  
      ```bash
      cloudctl case save \
        --case https://github.com/IBM/cloud-pak/raw/master/repo/case/${CASE_ARCHIVE} \
        --outputdir $HOME/offline/
      ```
 
   - Create the Meta ops project
  
    `oc new-project cpd-meta-ops`
    
   - Set up environment variables

   ```bash
    export OPERATOR_REGISTRY=docker.io/ibmcom    
    export CPD_REGISTRY=cp.icr.io/cp/cpd
    export CPD_REGISTRY_USER=cp
    export CPD_REGISTRY_PASSWORD=<apikey>
   
    export PRIVATE_REGISTRY=<private registry path> eg, "domain.com.io"
    export PRIVATE_REGISTRY_USER=<private registry user>
    export PRIVATE_REGISTRY_PASSWORD=<private registry password>
    export CASE_DIR=$HOME/offline/  "path to the case location"
    export NAMESPACE=$(oc project -q)

   ```

#### Operator Installation Airgapped

Ensure you have logged into the cluster with administrator credentials.

- Authenticate with the IBM entitled registry

    ```bash
     cloudctl case launch                      \
      --case ibm-cp-datacore                   \
      --namespace ${NAMESPACE}                 \
      --inventory cpdMetaOperatorSetup         \
      --action configure-creds-airgap          \
      --tolerance=1                            \
      --args "--registry $(echo ${CPD_REGISTRY} | cut -f1 -d"/") --user ${CPD_REGISTRY_USER} --pass ${CPD_REGISTRY_PASSWORD}"
    ```

- Authenticate with the target private registry

    ```bash
     cloudctl case launch                      \
      --case ibm-cp-datacore                   \
      --namespace ${NAMESPACE}                 \
      --inventory cpdMetaOperatorSetup         \
      --action configure-creds-airgap          \
      --tolerance=1                            \
      --args "--registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"
    ```

- Mirror Cloud Pak for Data operator and service images to your private registry. This uses `oc image mirror` API and may take up to an hour depending on the network speed to mirror all the images. You can also use the `cpd-cli` tool to [mirror selected services](#using-cloud-pak-for-data-pre-load-mages).

    ```bash
    cloudctl case launch                       \
      --case ibm-cp-datacore                   \
      --namespace ${NAMESPACE}                 \
      --inventory cpdMetaOperatorSetup         \
      --action mirror-images                   \
      --tolerance=1                            \
      --args "--registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD} --inputDir ${CASE_DIR}"
    ```

- (Non-OLM, OCP 3.11) Configure your cluster for airgap. This sets up the operator YAML and creates the `external-cpd-registry` secret.

  ```bash
    cloudctl case launch                          \
        --case ibm-cp-datacore                    \
        --namespace ${NAMESPACE}                  \
        --inventory cpdMetaOperatorSetup          \
        --action configure-cluster-airgap-native  \
        --tolerance=1                             \
        --args "--secret external-cpd-registry --registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"

  ```

 - (Non-OLM, OCP 3.11) Install the operator

      ```bash
      cloudctl case launch                          \
          --case ibm-cp-datacore                    \
          --namespace ${NAMESPACE}                  \
          --inventory cpdMetaOperatorSetup          \
          --action install-operator-native          \
          --tolerance=1                             \
          --args "--secret operator-registry --registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"
      ```
    Check the operator `ibm-cp-data-operator` deployed successfully
    
 - (OLM, OCP 4.x) Configure your cluster for airgap. This sets up global pull secrets, the `ImageContentSourcePolicy` and creates the `external-cpd-registry` secret.

  ```bash
    cloudctl case launch                         \
        --case ibm-cp-datacore                   \
        --namespace ${NAMESPACE}                 \
        --inventory cpdMetaOperatorSetup         \
        --action configure-cluster-airgap        \
        --tolerance=1                            \
        --args "--secret external-cpd-registry --registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"

  ```

 - (OLM, OCP 4.x) Install the catalog

    ```bash
    cloudctl case launch                          \
        --case ibm-cp-datacore                    \
        --namespace ${NAMESPACE}                  \
        --inventory cpdMetaOperatorSetup          \
        --action install-catalog                  \
        --tolerance=1                             \
        --args "--registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"
    ```
    
    The Cloud Pak for Data Operator should be available in your OpenShift console's OperatorHub view. Install the Operator by creating a subscription
 

## Using Cloud Pak for Data Pre-load Images 

- [Prepare your private registry](https://www.ibm.com/support/knowledgecenter/SSQNUZ_current/cpd/install/ag-install-prep.html) by downloading CPD service images and pushing to your private registry

For example, to load your private registry for Cloud Pak for Data control plane, use `lite` assembly

```bash
./cpd-cli preload-images --assembly lite --action transfer --ask-push-registry-credentials -r repo.yaml --transfer-image-to ${PRIVATE_REGISTRY}
```


## Cloud Pak for Data Control Plane Installation

- Create a CPD instance namespace and the CPD service resource
  
    `oc new-project cpd-tenant`

- Create a custom resource like this to install the CPD control plane
   
    ```
      apiVersion: metaoperator.cpd.ibm.com/v1
      kind: CPDService
      metadata:
       name: lite-cpdservice
      spec:
         serviceName: lite
         storageClass: <storage class>
         license: 
           accept: true
     ```
