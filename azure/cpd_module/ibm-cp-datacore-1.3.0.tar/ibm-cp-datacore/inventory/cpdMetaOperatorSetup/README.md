# Cloud Pak for Data Operator

 Cloud Pak for Data can be installed in an online or an air-gapped/custom environment using the operator. 

 - [Prerequisites](#prerequisites)
 - [Online Installation](#online-installation)
   - [Non-OLM](#non-olm)
     - [Operator Installation](#operator-installation)
   - [OLM (OCP 4.x)](#olm)
     - [Using OpenShift Console](#using-openshift-console)
       - [Install Catalog](#install-cpd-catalog)
       - [Operator Installation](#install-cpd-operator-using-console)
     - [Using CLI](#using-cli)
       - [Catalog & Operator Installation](#install-cpd-operator-thru-cli)
- [Airgapped Installation](#airgapped-installation)
  - [Set up](#set-up-for-airgapped-environment)
     - [Operator Installation Airgapped](#operator-installation-airgapped)
 - [Using Cloud Pak for Data Pre-load Images](#using-cloud-pak-for-data-pre-load-mages)
 - [Cloud Pak for Data Control Plane Installation](#cloud-pak-for-data-control-plane-installation) 
 - [CPDService Definition](#cpdservice-definition) 
 - [Operator Configuration](#operator-configuration)

 
## Prerequisites

 - cluster admininstator access to the OpenShift cluster
 - [`cloudctl` tool](https://github.com/IBM/cloud-pak-cli/releases) to run case commands
 - [`cpd-cli` tool](https://github.com/IBM/cpd-cli/releases) to prepare your private CPD registry for Airgapped environment.
 - Red Hat OpenShift version 3.11 or 4.3+
 - [Cloud Pak for Data case](https://github.com/IBM/cloud-pak/blob/master/repo/case/ibm-cp-datacore/1.3.0/ibm-cp-datacore-1.3.0.tgz) package tar file
 - A private docker registry for airgapped environments
 - In-cluster or a shared registry with sufficient size and proximity to CPD cluster 
 - A bastion node with internet connectivity and the access to the OpenShift cluster
 - Dynamic volume Provisioner or a storage class on the cluster that is supported by CPD
 - OpenShift projects
   - A "Meta Ops" project with a user with cluster administrator role 
   - A CPD Instance project with a user with a project admin or editor role.
   
 ## Online Installation

 - Download and extract the case package

    `tar -xf ibm-cp-datacore-1.3.0.tgz`


 ### Set up
 
   - Create the Meta ops project
  
      `oc new-project cpd-meta-ops`
    
   - Set up environment variables

      ```bash   
      export CPD_REGISTRY=cp.icr.io/cp/cpd
      export CPD_REGISTRY_USER=cp
      export CPD_REGISTRY_PASSWORD=<apikey>
      export NAMESPACE=cpd-meta-ops
      ```
   
### Non-OLM

### Operator Installation

 - (For OCP 3.11 ONLY) Create Service Account and assign cluster admin role
 
      ```
      cat <<EOF | oc apply -f -
      apiVersion: v1
      kind: ServiceAccount
      metadata:
        name: ibm-cp-data-operator-serviceaccount
      EOF

      oc adm policy add-cluster-role-to-user cluster-admin system:serviceaccount:${NAMESPACE}:ibm-cp-data-operator-serviceaccount
      ```
 
 - Install the operator 

      ```bash
      cloudctl case launch                        \
        --case ibm-cp-datacore                    \
        --namespace=${NAMESPACE}                  \
        --inventory cpdMetaOperatorSetup          \
        --action install-operator-native          \
        --tolerance=1                             \
        --args "--entitledRegistry ${CPD_REGISTRY} --entitledUser ${CPD_REGISTRY_USER} --entitledPass ${CPD_REGISTRY_PASSWORD}"
      ```

     Check the operator `ibm-cp-data-operator` deployed successfully
         

### OLM

### Using OpenShift Console

#### Prerequisites

 - Create a CPD meta namespace, say `cpd-meta-ops` and an instance namespace `cpd-tenant`
 
 - Create entitlement secret and add to operator service account of `cpd-meta-ops` project

    `oc create secret docker-registry ibm-entitlement-key --docker-server=cp.icr.io --docker-username=cp --docker-password=< api key > -n cpd-meta-ops`

#### Install CPD Catalog

  Log into the OpenShift console using cluster administrator credentials.

  Navigate to Menu-->Administration-->Cluster Settings-->Global Configuration-->Operator Hub-->Sources

  Click on "Create Catalog Source" and fill in the details

    name: ibm-cp-data-operator-catalog
    displayName: Cloud Pak for Data 
    image: docker.io/ibmcom/ibm-cp-data-operator-catalog:latest 
    publisher: IBM

  Select the default availability as "Cluster-wide catalog source"

  Hit "Create"

  After a few minutes the CPD Operator will be listed in the Menu-->Operators-->Operator Hub Catalog in the "Custom" Providers section.

#### Install CPD Operator using console

  Click on the `IBM Cloud Pak for Data Operator` --> Install

  On the Install page, select the default options to create the Subscription

    Installation Mode - All namespaces on the cluster
    Update Channel - v1.0
    Approval Strategy - Automatic

  Click on "Subscribe"

  At this point the operator pod will started.

### Using CLI

#### Install CPD Operator thru CLI

  -  Install the catalog and operator

      ```bash
      cloudctl case launch                          \
          --case ibm-cp-datacore                    \
          --namespace ${NAMESPACE}                  \
          --inventory cpdMetaOperatorSetup          \
          --action install-operator                 \
          --tolerance=1                             \
         --args "--entitledRegistry ${CPD_REGISTRY} --entitledUser ${CPD_REGISTRY_USER} --entitledPass ${CPD_REGISTRY_PASSWORD}"
      ```

     Check the operator `ibm-cp-data-operator` deployed successfully


## Airgapped Installation

### Set up for Airgapped Environment

   - Prepare a [private registry](https://www.ibm.com/support/knowledgecenter/SSGT7J_20.2/install/mirroring_operators.html#registry) and a [bastion node](https://www.ibm.com/support/knowledgecenter/SSGT7J_20.2/install/mirroring_operators.html#bastion) 
   - Download the case archive from [github](https://github.com/IBM/cloud-pak/blob/master/repo/case/ibm-cp-datacore/1.3.0/ibm-cp-datacore-1.3.0.tgz) and extract it

      `tar -xf ibm-cp-datacore-1.3.0.tgz`
 
   - Create the Meta ops project
  
      `oc new-project cpd-meta-ops`
    
   - Set up environment variables

      ```bash  
      export CPD_REGISTRY=cp.icr.io/cp/cpd
      export CPD_REGISTRY_USER=cp
      export CPD_REGISTRY_PASSWORD=<apikey>
   
      export PRIVATE_REGISTRY=<private registry path> eg, "domain.com.io"
      export PRIVATE_REGISTRY_USER=<private registry user>
      export PRIVATE_REGISTRY_PASSWORD=<private registry password>
      export NAMESPACE=cpd-meta-ops

      ```

#### Operator Installation Airgapped

Ensure you have logged into the cluster with administrator credentials.

Note: For OCP 3.11 servers, you need to install [oc client v4.3](https://mirror.openshift.com/pub/openshift-v4/clients/oc/4.3/linux/oc.tar.gz) in the execution path.

- Authenticate with the target private registry

    ```bash
     cloudctl case launch                      \
      --case ibm-cp-datacore                   \
      --inventory cpdMetaOperatorSetup         \
      --action configure-creds-airgap          \
      --tolerance=1                            \
      --args "--registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"
    ```

- Mirror Cloud Pak for Data operator images to your private registry. Note that you need the `cpd-cli` installed and should be available in the execution PATH. Specify the location of the `repo.yaml` with entitled registry authentication details. The `cpdservices` can specify a comma separated list of services, for eg. `wsl,wml,wkc`

    ```bash
    cloudctl case launch                       \
      --case ibm-cp-datacore                   \
      --inventory cpdMetaOperatorSetup         \
      --action mirror-images                   \
      --tolerance=1                            \
      --args "--cpdservices <comma separated service names> --repo repo.yaml --registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"
    ```

- (Non-OLM, OCP 3.11) Configure your cluster for airgap. This sets up the operator YAML and creates the `external-cpd-registry` secret.

  ```bash
    cloudctl case launch                          \
        --case ibm-cp-datacore                    \
        --namespace ${NAMESPACE}                  \
        --inventory cpdMetaOperatorSetup          \
        --action configure-cluster-airgap-native  \
        --tolerance=1                             \
        --args "--secret external-cpd-registry --registry ${PRIVATE_REGISTRY}/ibmcom --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"

  ```

 - (OLM, OCP 4.x) Configure your cluster for airgap. This sets up global pull secrets, the `ImageContentSourcePolicy` and creates the `external-cpd-registry` secret. Please note that the nodes will ripple start and may take few minutes for all nodes to be back up.

  ```bash
    cloudctl case launch                         \
        --case ibm-cp-datacore                   \
        --namespace ${NAMESPACE}                 \
        --inventory cpdMetaOperatorSetup         \
        --action configure-cluster-airgap        \
        --tolerance=1                            \
        --args "--secret external-cpd-registry --registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"

  ```

   - (Non-OLM, OCP 3.11) Install the operator

      ```bash
      cloudctl case launch                          \
          --case ibm-cp-datacore                    \
          --namespace ${NAMESPACE}                  \
          --inventory cpdMetaOperatorSetup          \
          --action install-operator-native          \
          --tolerance=1                             \
          --args "--secret operator-registry --registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"
      ```
    Check the operator `ibm-cp-data-operator` deployed successfully
    

 - (OLM, OCP 4.x) Install the catalog

    ```bash
    cloudctl case launch                          \
        --case ibm-cp-datacore                    \
        --namespace ${NAMESPACE}                  \
        --inventory cpdMetaOperatorSetup          \
        --action install-catalog                  \
        --tolerance=1                             \
        --args "--registry ${PRIVATE_REGISTRY} --user ${PRIVATE_REGISTRY_USER} --pass ${PRIVATE_REGISTRY_PASSWORD}"
    ```
    
    The Cloud Pak for Data Operator should be available in your OpenShift console's OperatorHub view. Install the Operator by creating a subscription.
 

## Cloud Pak for Data Control Plane Installation

- Create a CPD instance namespace and the CPD service resource
  
    `oc new-project cpd-tenant`

- Create a custom resource like this to install the CPD control plane
   
    ```
      apiVersion: metaoperator.cpd.ibm.com/v1
      kind: CPDService
      metadata:
       name: lite-cpdservice
      spec:
         serviceName: lite
         storageClass: <storage class>
         license: 
           accept: true
     ```

## CPDService Definition

  The CPDService resource represents any CPD service/add-ons that can be managed by the meta operator. It has
  the following attributes

|name               |default            |required|type           |description                                                                               |
|------------------ |-------------------|--------|---------------|----------------------------------------------------------------------------------------- |
|serviceName        |                   | yes    |  string       |    CPD Service name (assembly or the case name)                                          | 
|version            | latest            | no     |  string       |    CPD service version, use `latest` or the semver version. Default is `latest`          |
|storageClass       |                   | yes    |  string       |    Storage class to be used for the service                                              |
|flags              |                   | no     |  string       |    Optional service specific flags                                                       |
|autoPatch          |  false            | no     |  boolean       |    Always apply the latest patch available. Default is `false`.                          |
|overrideConfig     |                   | no     |  string       |    default override to be used for storage, eg `portworx` or `ocs`                       |
|customOverride     |                   | no     |  string       |    Custom override in base64 encoded format                                              |
|scale              |                   | no     |  string       |    Scale level required, for eg small, medium, large                                     |
|optionalModules    |                   | no     |  list<string> |    Additional modules that need to be installed                                          |
|serviceInstanceName|                   | no     |  string       |    Service instance name of the cpd service                                              |
|tetheredNamespace  |                   | no     |  string       |    Namespace for the service instance to be tethered to                                  |
|license.accept     |  false            | yes    |  boolean      |    License agreement for the CPD Service                                                 |

 ## Operator Configuration

 You can configure the operator for custom deployments. You can create the configMap `cpd-meta-admin-config` properties as follows.

  ```bash
  cat <<EOF | oc apply -f -
  apiVersion: v1
  data:
    manualADM: "false"
    skipImageTransfer: "false"
  kind: ConfigMap
  metadata:
    name: cpd-meta-admin-config
  EOF
  ```

|key               |default            |required|type           |description                                                                               |
|------------------|-------------------|--------|---------------|----------------------------------------------------------------------------------------- |
|manualAdm         | false             | yes    |  boolean      |    By default CPD operator requires elevated [cluster roles](deploy/cluster_role.yaml) as it administers individual services. An administrator can switch on this flag and run the `cpd-cli adm` commands manually if required.                 | 
|skipImageTransfer | false             | yes    |  boolean      |    The operator mirrors the Cloud Pak for Data images from the entitled registry to the OpenShift internal registry. This can turned off by enabling this property.|
