#!/bin/bash
set -e

while getopts "p:a:r:t:u:" opt; do
    case $opt in
        a)
            assemblies=$OPTARG # coma seperated assemblies
        ;;
        r)
            repo=$OPTARG #repo.yaml
        ;;
        t)
            registry=$OPTARG #registry to transfer image to
        ;;
        u)
            username=$OPTARG #registry username
        ;;
        p)
            regpass=$OPTARG #registry password
        ;;
    esac
done

[[ $# -eq 0 || -z $assemblies || -z $repo || -z $registry || -z $username || -z $regpass ]] && { echo "Usage: $0 -a <comma_seperated_assemblies> -r /path/to/repo.yaml -t <target_registry> -u <registry_username> -p <registry_password>"; exit 1; }

IFS=','; assembliesArr=($assemblies); unset IFS;

for assembly in "${assembliesArr[@]}"
do
    echo "Mirroring images for $assembly"
    set -x
    cpd-cli preload-images --action transfer --transfer-image-to=$registry --target-registry-username="$username" --target-registry-password="$regpass" -a $assembly -r $repo --accept-all-licenses
done
echo "############# Mirroring Complete ################"