#### Prerequisites
This task must be completed by a Red Hat OpenShift cluster administrator. The administrator must have an [access]( https://cloud.ibm.com/docs/openshift?topic=openshift-users) policy in IBM Cloud Identity and Access Management that has an Operator role or higher.

#### Changes applied
The script makes the following changes to your Red Hat OpenShift cluster:

*  Increases the size of the Image registry volume to 200 GB. This change incurs cost to your account.
*  Creates the security context constraints that are required for Cloud Pak for Data.
*  Grants the security context constraints to the service accounts that are required for Cloud Pak for Data.

#### Image registry permissions
The instructions in this preinstallation script assume that your IBM Cloud user account is the same as your infrastructure account and you have permission to modify the storage in classic infrastructure. If this is not true, you must update the size for the Image registry volume from your infrastructure account.

You can either:

*  Edit the settings of the volume that is bound to image-registry-storage pvc from the IBM Cloud console by going to **Classic Infrastructure** > **Storage** > **File Storage**.
*  Manually run the commands in the following script to update the Image registry size from your infrastructure account.

If you are installing other applications in the cluster, or more Cloud Pak for Data services, you must increase the image registry space to more than 300GB.

1. Create an API key. To learn more, see [Logging in with a federated ID](https://cloud.ibm.com/docs/iam?topic=iam-federated_id). 
```
oc login <openshift_console_url> --token <login_token>
ibmcloud login --apikey <apikey_having_access_to_modify_volume>
```
2. Log in to the IBM Cloud command line interface and run the following code snippet:
```
cat <<EOF >>modifyVol.sh
#!/bin/bash
#Increase storage for docker registry
registry_pv=\`oc get pvc -n openshift-image-registry | grep "image-registry-storage" | awk '{print \$3}'\`
volid=\`oc describe pv \$registry_pv -n openshift-image-registry | grep volumeId\`
IFS='='
read -ra vol <<< "\$volid"
volume=\${vol[1]}
echo volume id is \$volume

ibmcloud sl file volume-detail \$volume

if [[ \$? -eq 0 ]]; then
capval=\`ibmcloud sl file volume-detail \$volume | awk '\$1=="Capacity" {print \$3}'\`
  if [[ \$capval < 200 ]]; then
     ibmcloud sl file volume-modify \$volume --new-size 200 --force
     for i in {1..10}; do
       cap=\`ibmcloud sl file volume-detail \$volume | awk '\$1=="Capacity" {print \$3}'\`
       if [[ \$cap == 200 ]]; then
         echo "Image registry Volume is modified"
         break
       else
         sleep 30
       fi
      echo "Looks like it is taking time to reflect the updated size for Image Regsitry volume. please confirm that the size has been modified and start the CP4D installation"
     done
  fi
else
echo "The logged-in user does not have the privilege required to modify the storage. Before proceeding with the install, please make sure the registry volume size has been modified"
fi
EOF
chmod a+x modifyVol.sh
./modifyVol.sh
```

#### Run the preinstallation script

If you are not a cluster administrator, click **Share link**. Copy the link and share it with your administrator. 

Otherwise, click **Run** to run the following preinstallation script in the project that you specified in **Configure your installation environment**. It has the same effect regardless of the number of times it is run.
