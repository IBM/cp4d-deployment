#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2020. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

# LOGIN
printf "%s" "$KUBECONFIG_VALUE" > ./kubeconfig.json
printf "%s" "$KUBECONFIG_PEM_VALUE" > ./ca.pem

# Clean up pem file contents
sed -i 's/\\n/\n/g' ca.pem
sed -i 's/\"//g' ca.pem

# Arguments
export NAMESPACE=${JOB_NAMESPACE}
export STORAGE_CLASS=${storage}
export DOCKER_USERNAME=${DOCKER_REGISTRY_USER:-ekey}
export DOCKER_REGISTRY=${DOCKER_REGISTRY:-cp.icr.io/cp/cpd}
if [[ "${ENVIRONMENT}" == "STAGING" ]]; then
  export DOCKER_REGISTRY="cp.stg.icr.io/cp/cpd"
fi
export DOCKER_REGISTRY_PASS=${DOCKER_REGISTRY_PASS}
export WKC="${wkc}"
export WML="${wml}"
export WSL="${wsl}"
export DV="${dv}"
export AIOPENSCALE="${aiopenscale}"
export STREAMS="${streams}"
export SPARK="${spark}"
export CDE="${cde}"
export DB2WH="${db2wh}"
export DATAGATE="${datagate}"
export RSTUDIO="${rstudio}"
export DMC="${dmc}"

#Do not allow to update the already installed workspace
installoppod=`oc get pods -n ${NAMESPACE} | grep install-operator | awk '{print $1}'`
if [[ $installoppod != "" ]]; then
   version=`oc exec -it $installoppod -n ${NAMESPACE} -- printenv CPD_VERSION`
   if [[ $version != "3.5.1" ]]; then
     echo -e "\e[1m Upgrade is not supported. Please Refer to the Cloud Pak for Data  Knowledge Center link https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/install/upgrade-overview.html to upgrade \e[0m"
     exit 1
   fi
fi



#Check Portworx storage is configured in the cluster
if [[ ${STORAGE_CLASS} == "portworx-shared-gp3" ]]; then
  if ! oc get sc | awk '{print $2}' | grep -q 'kubernetes.io/portworx-volume'; then
     echo -e "\e[1m Portworx storage is not configured on this cluster. Please configure portworx first and try installing \e[0m"
     exit 1
  fi
fi

#Create Performance Storageclass if user choses the option
if [[ ${STORAGE_CLASS} == "ibmc-file-custom-gold-gid" ]]; then
   oc get sc | grep ibmc-file-custom-gold-gid
   if [[ $? -eq 1 ]]; then
   cat << EOF | kubectl apply -f -
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  labels:
    addonmanager.kubernetes.io/mode: EnsureExists
    kubernetes.io/cluster-service: "true"
  name: ibmc-file-custom-gold-gid
parameters:
  billingType: hourly
  classVersion: "2"
  gidAllocate: "true"
  sizeIOPSRange: |-
    [20-39]Gi:[1000-1000]
    [40-79]Gi:[2000-2000]
    [80-99]Gi:[4000-4000]
    [100-499]Gi:[6000-6000]
    [500-999]Gi:[10000-10000]
    [1000-1999]Gi:[20000-20000]
    [2000-2999]Gi:[40000-40000]
    [3000-3999]Gi:[48000-48000]
    [4000-7999]Gi:[48000-48000]
    [8000-9999]Gi:[48000-48000]
    [10000-12000]Gi:[48000-48000]
  type: Performance
provisioner: ibm.io/ibmc-file
reclaimPolicy: Delete
volumeBindingMode: Immediate
EOF
fi
fi

#Check route for image registry if it is not created
if ! oc get route -n openshift-image-registry | awk '{print $1}'| grep -q 'image-registry'; then
  echo "Create image registry route"
  oc create route reencrypt --service=image-registry -n openshift-image-registry
else
  policy=`oc get route -n openshift-image-registry | awk '$1 == "image-registry" {print $5}'`
  if [[ $policy != "reencrypt" ]]; then
  oc delete route image-registry -n openshift-image-registry
  oc create route reencrypt --service=image-registry -n openshift-image-registry
  fi
fi

oc annotate route image-registry --overwrite haproxy.router.openshift.io/balance=source -n openshift-image-registry

# create pull secret
oc create secret docker-registry icp4d-anyuid-docker-pull -n ${NAMESPACE} --docker-server=${DOCKER_REGISTRY} --docker-username=${DOCKER_USERNAME} --docker-password=${DOCKER_REGISTRY_PASS}
oc secrets -n ${NAMESPACE} link cpdinstall icp4d-anyuid-docker-pull --for=pull
oc create secret docker-registry icp4d-anyuid-docker-pull -n kube-system --docker-server=${DOCKER_REGISTRY} --docker-username=${DOCKER_USERNAME} --docker-password=${DOCKER_REGISTRY_PASS}
oc secrets -n kube-system link cpdinstall icp4d-anyuid-docker-pull --for=pull
oc create secret docker-registry sa-${NAMESPACE} -n ${NAMESPACE} --docker-server=${DOCKER_REGISTRY} --docker-username=${DOCKER_USERNAME} --docker-password=${DOCKER_REGISTRY_PASS}

cat << EOF | kubectl apply --namespace ${NAMESPACE} -f -
---
apiVersion: v1
kind: Secret
metadata:
  name: cp4dinstaller-sensitive-data
  namespace: ${NAMESPACE}
type: Opaque
data:
  docker-registry-username: "$(echo -n ${DOCKER_USERNAME} | base64 -w0)"
  docker-registry-password: "$(echo -n ${DOCKER_REGISTRY_PASS} | base64 -w0)"
EOF

export ID=$RANDOM


cat << EOF | kubectl apply --namespace ${NAMESPACE} -f - 
---
apiVersion: batch/v1
kind: Job
metadata:
  name: cloud-installer-$ID
  labels:
    app: cp4data-installer-$ID
spec:
  backoffLimit: 0
  completions: 1
  parallelism: 1
  template:
    metadata:
      labels:
        app: cp4data-installer-$ID
      annotations:
        productName: IBM Cloud Pak for Data
        productVersion: 3.5.0
    spec:
      containers:
      - env:
        - name: NAMESPACE 
          value: ${NAMESPACE}
        - name: STORAGE_CLASS
          value: ${STORAGE_CLASS}
        - name: DOCKER_REGISTRY
          value: ${DOCKER_REGISTRY}
        - name: DOCKER_USERNAME
          valueFrom:
            secretKeyRef:
              name: cp4dinstaller-sensitive-data
              key: docker-registry-username
        - name: DOCKER_REGISTRY_USER
          valueFrom:
            secretKeyRef:
              name: cp4dinstaller-sensitive-data
              key: docker-registry-username
        - name: DOCKER_REGISTRY_PASS
          valueFrom:
            secretKeyRef:
              name: cp4dinstaller-sensitive-data
              key: docker-registry-password
        - name: DEPLOY_WKC
          value: "${WKC}"
        - name: DEPLOY_WSL
          value: "${WSL}"
        - name: DEPLOY_WML
          value: "${WML}"
        - name: DEPLOY_AIOPENSCALE
          value: "${AIOPENSCALE}"
        - name: DEPLOY_DV
          value: "${DV}"
        - name: DEPLOY_STREAMS
          value: "${STREAMS}"
        - name: DEPLOY_CDE
          value: "${CDE}"
        - name: DEPLOY_SPARK
          value: "${SPARK}"
        - name: DEPLOY_DB2WH
          value: "${DB2WH}"
        - name: DEPLOY_DATAGATE
          value: "${DATAGATE}"
        - name: DEPLOY_RSTUDIO
          value: "${RSTUDIO}"
        - name: DEPLOY_DMC
          value: "${DMC}"
        name: installer
        image: ${DOCKER_REGISTRY}/cp4d-installer:3.5.0-amd64
        imagePullPolicy: Always
        resources:
          limits:
            memory: "500Mi"
            cpu: 1
        command: [ "/bin/sh", "-c" ]
        args: [ "./deploy-cp4data.sh; sleep 300" ]
      serviceAccountName: cpdinstall
      imagePullSecrets:
      - name: icp4d-anyuid-docker-pull
      restartPolicy: Never
EOF
[[ $? -ne 0 ]] && exit 1

sleep 60
POD=$(kubectl get pods -n ${NAMESPACE} -l app=cp4data-installer-$ID -o jsonpath="{.items[0].metadata.name}")

if [[ ${POD} != "" ]]; then
echo "Waiting for ${POD} is running"
for ((retry=0;retry<=9999;retry++)); do
  if [[ -z "$POD" ]]; then
      echo "Waiting for installer pod to start."
      sleep 2
  else
    oc get pod ${POD} -n ${NAMESPACE} |grep '1/1'
    [[ $? -eq 0 ]] && break

    # Restart pod after 10 min
      if [[ ${retry} -eq 60 ]]; then
        echo "Restart the pod and check."
        oc describe pod ${POD} -n ${NAMESPACE}
        oc delete pod ${POD} -n ${NAMESPACE} --grace-period=0 --force
        POD=$(kubectl get pods -n ${NAMESPACE} -l app=cp4data-installer-$ID -o jsonpath="{.items[0].metadata.name}")
      fi


    # 15 min timeout
      if [[ ${retry} -eq 90 ]]; then
        echo "Timeout to wait for installer pod up and running, it could be the image pull failing."
        echo "Please use command 'oc get pod ${POD}' to check details"
        oc describe pod ${POD} -n ${NAMESPACE}
        oc logs ${POD} -n ${NAMESPACE}
        exit 1
      fi
  fi

  sleep 10
done
else
echo "Installer pod is not created yet"
oc describe job cp4data-installer-$ID
fi


sleep 3
echo "Tailing the pod log"
oc logs -n ${NAMESPACE} --follow $POD
status=`oc get pods -n ${NAMESPACE} | grep $POD | awk '{print $3}'`
if [[ $status != "Completed" ]]; then
for (( retry=0;retry<=20;retry++)); do
  oc logs -n ${NAMESPACE} $POD --tail=30 | grep -q "Installation not successful\|Access Cloud Pak for Data console using the address"
  if [[ $? -eq 1 ]]; then
  echo "Tailing the pod log"
  oc logs -n ${NAMESPACE} --follow $POD --tail=30
  else
  break
  fi
done 
fi

sleep 10

#Get operator pod
oppod=`oc get pods -n ${NAMESPACE} | grep install-operator | awk '{print $1}'`
if [[ $oppod != "" ]]; then
exit $(oc exec -it $oppod -n ${NAMESPACE} -- cat /mnt/shared/services.txt | grep -q lite)
else
exit 1
fi
