You can specify which services you want to install in Cloud Pak for Data. For each service that you want to install, set the value of the parameter to `true`.

The default value for each service is set to `false`. The Cloud Pak for Data Control Pane is installed by default if you do not specify any services to install.  

After you click **Install**, you are redirected to the workspace to track and manage your installation. In the workspace, you can find the URL for IBM Cloud Pak for Data, which you can access after the installation is complete.
