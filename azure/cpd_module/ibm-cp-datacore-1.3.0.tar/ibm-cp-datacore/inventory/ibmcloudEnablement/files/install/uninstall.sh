#!/bin/bash

if oc get project | awk '{print $1}'| grep -i ${JOB_NAMESPACE}; then 
 oc delete project ${JOB_NAMESPACE} &
 pid=$!
 count=$(ps -A| grep $pid |wc -l)
 a=0
  	until [[ $count -eq 0 || $a -eq 60 ]]
	do
		sleep 15s
		count=$(ps -A| grep $pid |wc -l)
		a=`expr $a + 1`
	done
 if ps -A| grep $pid |wc -l; then
 kill -9 $pid
 fi		
fi

if oc get project | awk '{print $1}'| grep -i ${JOB_NAMESPACE}; then
 for i in $(oc get po -n ${JOB_NAMESPACE} | grep -i Terminating | awk '{print $1}'); do oc delete pod $i --grace-period=0 --force -n ${JOB_NAMESPACE}; done
 oc delete project ${JOB_NAMESPACE}
fi

count2=$(oc get project | grep -i ${JOB_NAMESPACE} | wc -l)
b=0
	until [[ $count2 -eq 0 || $b -eq 20 ]]
	do
		sleep 15s
		count2=$(oc get project | grep -i ${JOB_NAMESPACE} | wc -l)
		b=`expr $b + 1`
	done

if oc get project | grep -i ${JOB_NAMESPACE} | grep -i Terminating; then
	echo "Project still in Terminating state.. Please wait for few minutes and check the status"
elif oc get project | grep -i ${JOB_NAMESPACE} | grep -i Active; then
	echo "Project still in Active state.. Please delete the project manually"
else
	echo "Project deleted Successfully"
fi