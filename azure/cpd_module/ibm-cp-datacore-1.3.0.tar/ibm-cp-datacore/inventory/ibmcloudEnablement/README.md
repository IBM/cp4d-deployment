# Introduction

IBM Cloud Pak for Data is an end-to-end data and AI platform that you can use to modernize how your organization collects, organizes, and analyzes data to infuse AI into your business. [Learn more about Cloud Pak for Data](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/overview/overview.html).

# Features

The features that you can use depend on the services that you install. You can choose which services to install when you install Cloud Pak for Data on IBM Cloud.


* [Apache Spark](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/spark.html)
	Use the Analytics Engine powered by Apache Spark as a compute engine to run analytical and machine learning jobs.
* [Cognos Dashboards](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/cde.html)
	Use sophisticated visualizations in an analytics project to identify patterns in your data so that you can make timely and effective decisions.
* [Data Virtualization](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/dv.html)
	Create data sets from disparate data sources so that you can query and use the data as if it came from a single source. When you provision the service, make sure to check the **You must check this box if you updated the kernel semaphore parameter** check box and you use the recommended storage class mentioned in the storage section in below documentation.
* [Db2 Data Gate](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/dg.html)
	Extract, load, and synchronize your mission-critical data from Db2 for z/OS to Cloud Pak for Data for quick access by your new, high volume, read-only transactional, and analytic applications.
* [Db2 Data Management Console](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/dmc.html)
        Administer, monitor, manage and optimize the performance of IBM Db2 for Linux, UNIX and Windows databases.
* [Db2 Warehouse](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/db2wh.html)
	Take advantage of in-memory data processing and in-database analytics in an analytics data warehouse that supports automated scaling.
* [IBM Streams](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/streams.html)
	Enable continuous and fast analysis of large volumes of moving data so that you can develop and run analytics applications that process in-flight data.
        When IBM Streams is installed, [Streams Flows](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/stflows.html) is also installed.
* [RStudio Server](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/rstudio.html)
	Use an integrated development environment for working with R in Watson Studio to create R Shiny applications.
* [Watson Knowledge Catalog](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/wkc.html)
	Know your data inside and out. Ensure that your data is high quality, aligns with business objectives, and complies with regulations.
* [Watson Studio](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/wsl.html)
	Unearth the meaning in your data. Build custom models and infuse your business with AI and machine learning.
* [Watson Machine Learning](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/wml.html)
	Build analytical models and neural networks that are trained with your data. Then, deploy them into production at scale.
* [Watson OpenScale](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/svc-welcome/aiopenscale.html)
	Infuse your AI with trust and transparency. Understand how your AI models make decisions to detect and mitigate bias.

**Tip:** If you want to install a service later to the existing deployed namespace, you can return to the **Deployment values** section and set the appropriate parameter to **true** or you can select a service from the Services catalog and follow the installation instructions for the service.

For more information, see [Installing services](https://cloud.ibm.com/docs/cloud-pak-data?topic=cloud-pak-data-install-services).


# Details

## License

To deploy Cloud Pak for Data, you must already have a valid license. If your organization has already purchased a valid license, your account administrator must bind the entitlement to your IBM Cloud account before you can assign an entitlement by using the **Create** tab. If your organization has not yet purchased a license, contact your IBM sales representative. For more information, see [Obtaining the installation files](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/install/installation-files.html).

## Prerequisites

To install Cloud Pak for Data on IBM Cloud, you must have an [IBM Red Hat OpenShift Version 4.5.4 or above](https://cloud.ibm.com/kubernetes/catalog/openshiftcluster) classic cluster on IBM Cloud. The installation is not supported on an IBM Red Hat OpenShift Cluster Virtual Private Cloud (Gen2). For more information, see [Getting started with Red Hat OpenShift on IBM Cloud](https://cloud.ibm.com/docs/openshift?topic=openshift-getting-started).

### Roles

To install Cloud Pak for Data on IBM Cloud, a user must have the following IAM Roles:
 * Account Management > License and Entitlement > Platform Editor role -  To assign license
 * IAM Services > Schematics > Service Manager role in any resource group -  To create workspace
 * Classic Infrastructure > Services > Storage Manage , Classic Infrastructure > Account > Add/Upgrade Storage - To modify image registry volume
 * IAM Services > Kubernetes Service > Service Manager role - To run pre-install script
 * IAM Services > Kubernetes Service > Service Writer role - To run Install script

### Storage 

The following storage options are supported to install Cloud Pak for Data:
* Single zone classic cluster with storage IBM Cloud File Storage
* Single zone classic cluster with storage IBM Cloud Portworx Enterprise
* Multi zone classic cluster with storage IBM Cloud Portworx Enterprise

If you are using a single zone classic cluster with IBM Cloud File Storage, IBM Cloud accounts have a default quota of 250 storage volumes. Before you start the installation, ensure that each account has enough storage volumes for Cloud Pak for Data to be installed. For more information, see [How many volumes can be ordered?](https://cloud.ibm.com/docs/infrastructure/FileStorage?topic=FileStorage-file-storage-faqs#how-many-volumes-can-be-ordered)

If you are using Portworx storage, you must configure IBM Cloud Portworx Enterprise on the cluster before you start the Cloud Pak for Data installation. For more information, see [Configure Portworx](https://cloud.ibm.com/docs/openshift?topic=openshift-portworx). You must use the 10 IOPS/GB option for the Endurance block storage used to configure Portworx.

Make sure the image registry volume size is modified before installation. For more information, see Complete the Preinstallation on the **Create** tab. If the OpenShift cluster image registry has images of other applications, you might need to increase the image registry volume size to more than 200GB. 

You must also ensure that your cluster has sufficient resources and is configured to use supported storage.

### Resources Required
By default, you provision a 3-node Red Hat OpenShift cluster. Each node is automatically provisioned with a 25 GB SSD primary disk and 100 GB SSD secondary disk. This disk storage is different from persistent storage.

To install only Cloud Pak for Data Control plane, you need 6 VPCs. The minimum recommendation for Cloud Pak for Data is 16 cores, 64GB RAM, 1 TB Persistent storage.

This minimum recommendation is not sufficient to install all of the services.  You must ensure that you have sufficient resources for the services that you planned to install. 

The installation does not verify whether there are sufficient resources on the cluster to install Cloud Pak for Data. If you are running other applications on your Red Hat OpenShift cluster, ensure that you have sufficient resources on the cluster before you install Cloud Pak for Data.

For more information, see [System Requirements for IBM Cloud Pak for Data](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/plan/rhos-reqs.html).

### Supported storage

When you install your Red Hat OpenShift cluster, IBM Cloud File Storage is set up by default. If you choose to use Portworx storage, you must configure Portworx before you start the Cloud Pak for Data installation.

For more information, see [Storing data on classic IBM Cloud File Storage](https://cloud.ibm.com/docs/openshift?topic=openshift-file_storage) and [Storing data on Portworx](https://cloud.ibm.com/docs/openshift?topic=openshift-portworx).

You can choose one of the following options as storage for Cloud Pak for Data:
* EnduranceFileStorage - This option uses the storage class `ibmc-file-gold-gid` to install Cloud Pak for Data. For more information, see [Endurance Storage](https://cloud.ibm.com/docs/FileStorage?topic=FileStorage-about#provisioning-with-endurance-tiers). You can use the same storage class while provisioning the instances of services.
* PerformanceFileStorage - This option uses the storage class `ibmc-file-custom-gold-gid` to install Cloud Pak for Data. For more information, see [Performance Storage](https://cloud.ibm.com/docs/FileStorage?topic=FileStorage-about#provisioning-with-performance). You can use the same storage class while provisioning the instances of services.
* Portworx - This option uses the storage class mentioned in [Storage considerations](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/plan/storage_considerations.html). You can choose the storage class mentioned in the service instance creation documentation when you provision instances of services.

Cloud Pak for Data uses dynamic provisioning. You must have sufficient persistent storage for the services that you plan to install.

For more information, see [System Requirements for IBM Cloud Pak for Data](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/plan/rhos-reqs.html).


## Configuration
When you install Cloud Pak for Data, you can specify which services are on the Cloud Pak for Data control plane. 

1. To install a service, set the appropriate parameter to **true** in the **Deployment values** section.
1. After you install Cloud Pak for Data, log in to the web console with the `admin` username and change the default password `password`. 
1. Launch the web console from the workspace by clicking **Offering Dashboard**.

For more information, see [Getting started with Cloud Pak for Data](https://cloud.ibm.com/docs/cloud-pak-data?topic=cloud-pak-data-getting-started).

## Limitations
For more information, see [Limitations](https://cloud.ibm.com/docs/cloud-pak-data?topic=cloud-pak-data-limitations).

## Documentation

Documentation for IBM Cloud Pak for Data Version 3.5.0 is available on [IBM Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSQNUZ_3.5.0/cpd/overview/welcome.html).

## Images
![Cloud Pak for Data image gallery](images/CP4D_image_gallery.mp4)

